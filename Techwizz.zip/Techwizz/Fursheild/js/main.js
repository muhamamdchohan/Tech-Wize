// Main JavaScript for FurShield Application

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Navbar scroll effect
    const navbar = document.querySelector('.navbar');
    if (navbar) {
        window.addEventListener('scroll', function() {
            if (window.scrollY > 50) {
                navbar.style.padding = '10px 0';
                navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
            } else {
                navbar.style.padding = '15px 0';
                navbar.style.boxShadow = '0 2px 20px rgba(0, 0, 0, 0.1)';
            }
        });
    }
    
    // Animate elements on scroll
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.feature-card, .stats-card, .pet-card');
        
        elements.forEach(element => {
            const position = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;
            
            if (position < screenPosition) {
                element.style.opacity = 1;
                element.style.transform = 'translateY(0)';
            }
        });
    };
    
    // Set initial state for animation
    const animatedElements = document.querySelectorAll('.feature-card, .stats-card, .pet-card');
    animatedElements.forEach(element => {
        element.style.opacity = 0;
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    });
    
    // Run on load and scroll
    window.addEventListener('load', animateOnScroll);
    window.addEventListener('scroll', animateOnScroll);
    
    // Counter animation for stats
    const counterElements = document.querySelectorAll('.counter');
    if (counterElements.length > 0) {
        const counters = document.querySelectorAll('.counter');
        const speed = 200;
        
        counters.forEach(counter => {
            const updateCount = () => {
                const target = +counter.getAttribute('data-target');
                const count = +counter.innerText;
                
                const inc = target / speed;
                
                if (count < target) {
                    counter.innerText = Math.ceil(count + inc);
                    setTimeout(updateCount, 1);
                } else {
                    counter.innerText = target;
                }
            };
            
            updateCount();
        });
    }
});

// Form validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            let isValid = true;
            const inputs = form.querySelectorAll('input[required]');
            
            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    input.classList.add('is-invalid');
                } else {
                    input.classList.remove('is-invalid');
                }
            });
            
            if (isValid) {
                // Form is valid, proceed with submission
                alert('Form submitted successfully!');
                form.reset();
            }
        });
    }
}

// Initialize forms
document.addEventListener('DOMContentLoaded', function() {
    validateForm('loginForm');
    validateForm('registerForm');
    validateForm('contactForm');
});

// Pet profile management
const petManager = {
    pets: [],
    
    addPet: function(pet) {
        this.pets.push(pet);
        this.saveToLocalStorage();
        return true;
    },
    
    getPets: function() {
        this.loadFromLocalStorage();
        return this.pets;
    },
    
    getPetById: function(id) {
        return this.pets.find(pet => pet.id === id);
    },
    
    updatePet: function(id, updatedPet) {
        const index = this.pets.findIndex(pet => pet.id === id);
        if (index !== -1) {
            this.pets[index] = {...this.pets[index], ...updatedPet};
            this.saveToLocalStorage();
            return true;
        }
        return false;
    },
    
    deletePet: function(id) {
        const index = this.pets.findIndex(pet => pet.id === id);
        if (index !== -1) {
            this.pets.splice(index, 1);
            this.saveToLocalStorage();
            return true;
        }
        return false;
    },
    
    saveToLocalStorage: function() {
        localStorage.setItem('furshield_pets', JSON.stringify(this.pets));
    },
    
    loadFromLocalStorage: function() {
        const pets = localStorage.getItem('furshield_pets');
        if (pets) {
            this.pets = JSON.parse(pets);
        }
    }
};

// Initialize pet manager
document.addEventListener('DOMContentLoaded', function() {
    petManager.loadFromLocalStorage();
});

// Appointment management
const appointmentManager = {
    appointments: [],
    
    addAppointment: function(appointment) {
        this.appointments.push(appointment);
        this.saveToLocalStorage();
        return true;
    },
    
    getAppointments: function() {
        this.loadFromLocalStorage();
        return this.appointments;
    },
    
    saveToLocalStorage: function() {
        localStorage.setItem('furshield_appointments', JSON.stringify(this.appointments));
    },
    
    loadFromLocalStorage: function() {
        const appointments = localStorage.getItem('furshield_appointments');
        if (appointments) {
            this.appointments = JSON.parse(appointments);
        }
    }
};

// Initialize appointment manager
document.addEventListener('DOMContentLoaded', function() {
    appointmentManager.loadFromLocalStorage();
});